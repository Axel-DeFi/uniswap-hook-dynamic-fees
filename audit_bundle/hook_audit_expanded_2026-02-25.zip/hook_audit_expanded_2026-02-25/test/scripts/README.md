# Test scripts

This directory is reserved for **test-only** scripts (local Anvil helpers, fuzz harness runners, etc.).
Production/ops scripts live in `/scripts`.
